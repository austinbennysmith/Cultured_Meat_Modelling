#!/bin/bash
a=3
b=4
echo $a
echo $((a*b))
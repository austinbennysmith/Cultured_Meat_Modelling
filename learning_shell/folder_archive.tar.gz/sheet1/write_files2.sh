#!/bin/bash
mkdir abcde
echo "Hello, World!" >> /users/asmit101/spot/abcde/hello.txt

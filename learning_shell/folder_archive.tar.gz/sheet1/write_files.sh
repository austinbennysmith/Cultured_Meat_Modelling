#!/bin/bash
mkdir abcde
for f in {0..100}
do
	echo "Hello, World!" >> /users/asmit101/spot/abcde/hello.txt
done

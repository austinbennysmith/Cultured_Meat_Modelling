#!/bin/sh
sed -i -e 's/GetRidOfMe//g' 3c.dat
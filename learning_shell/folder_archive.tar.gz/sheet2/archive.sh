#!/bin/sh
tar -cvf myarchive.tar.gz *.jpg
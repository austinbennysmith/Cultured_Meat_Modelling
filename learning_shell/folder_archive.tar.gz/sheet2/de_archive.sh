#!/bin/bash
tar -xf myarchive.tar.gz